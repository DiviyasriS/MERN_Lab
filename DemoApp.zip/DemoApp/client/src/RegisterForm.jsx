import axios from "axios";
import React, { useState } from "react";
import "./RegisterForm.css";

function RegisterForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("");
  const [status, setStatus] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:9000/register", { name, email, phone, location })
      .then(result=>setStatus(result.data))
        .catch(err=>setStatus(err));
  };

  return (
    <div className="container">
      <div className="form-container">
        <h3>Register</h3>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Name</label>
            <input type="text" placeholder="Enter your name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="input-group">
            <label>Email</label>
            <input type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="input-group">
            <label>Phone</label>
            <input type="number" placeholder="Enter your phone number" value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </div>
          <div className="input-group">
            <label>Location</label>
            <input type="text" placeholder="Enter your location" value={location} onChange={(e) => setLocation(e.target.value)} required />
          </div>
          <button type="submit" className="submit-btn">Sign Up</button>
          <div className="status-message">{status}</div>
        </form>
      </div>
    </div>
  );
}

export default RegisterForm;
