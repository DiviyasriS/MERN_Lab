// postcss.config.cjs
module.exports = {
    plugins: {
      "@tailwindcss/postcss": {},  // Correct package for Tailwind PostCSS plugin
      autoprefixer: {},
    },
  };
  